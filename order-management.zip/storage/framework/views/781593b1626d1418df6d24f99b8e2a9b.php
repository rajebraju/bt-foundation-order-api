<!doctype html>
<html>
<head><meta charset="utf-8"><title>Order Placed</title></head>
<body>
<h2>Thank you — Order <?php echo e($order->order_number); ?> received</h2>
<p>Hi <?php echo e($order->customer->name); ?>,</p>
<p>We have received your order. Summary:</p>
<ul>
<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($item->quantity); ?> x <?php echo e($item->variant->title ?? $item->product->name); ?> — <?php echo e(number_format($item->line_total,2)); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<p>Subtotal: <?php echo e(number_format($order->subtotal,2)); ?><br>
Total: <?php echo e(number_format($order->total,2)); ?></p>
</body>
</html>
<?php /**PATH D:\Soft Solution Media\BTH-Assastment\order-management\resources\views/emails/order_placed.blade.php ENDPATH**/ ?>