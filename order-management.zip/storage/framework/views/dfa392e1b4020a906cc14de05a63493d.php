<!doctype html>
<html>
<head><meta charset="utf-8"><title>Invoice <?php echo e($order->order_number); ?></title>
<style>
body { font-family: DejaVu Sans, sans-serif; font-size:12px; }
table { width:100%; border-collapse: collapse; }
table, th, td { border: 1px solid #ddd; padding: 8px; }
</style>
</head>
<body>
<h1>Invoice - <?php echo e($order->order_number); ?></h1>
<p>Date: <?php echo e($order->created_at->toDateString()); ?></p>
<p>Customer: <?php echo e($order->customer->name); ?> (<?php echo e($order->customer->email); ?>)</p>
<table>
<thead><tr><th>Item</th><th>Qty</th><th>Unit Price</th><th>Line Total</th></tr></thead>
<tbody>
<?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($i->variant->title ?? $i->product->name); ?></td>
<td><?php echo e($i->quantity); ?></td>
<td><?php echo e(number_format($i->unit_price,2)); ?></td>
<td><?php echo e(number_format($i->line_total,2)); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<p>Subtotal: <?php echo e(number_format($order->subtotal,2)); ?></p>
<p>Shipping: <?php echo e(number_format($order->shipping,2)); ?></p>
<p>Tax: <?php echo e(number_format($order->tax,2)); ?></p>
<h3>Total: <?php echo e(number_format($order->total,2)); ?></h3>
</body>
</html>
<?php /**PATH D:\Soft Solution Media\BTH-Assastment\order-management\resources\views/invoices/invoice.blade.php ENDPATH**/ ?>