<!doctype html>
<html>
<head><meta charset="utf-8"><title>Order Cancelled</title></head>
<body>
<h3>Order <?php echo e($order->order_number); ?> Cancelled</h3>
<p>Dear <?php echo e($order->customer->name); ?>,</p>
<p>Your order has been cancelled. If you need help, contact support.</p>
</body>
</html>
<?php /**PATH D:\Soft Solution Media\BTH-Assastment\order-management\resources\views/emails/order_cancelled.blade.php ENDPATH**/ ?>